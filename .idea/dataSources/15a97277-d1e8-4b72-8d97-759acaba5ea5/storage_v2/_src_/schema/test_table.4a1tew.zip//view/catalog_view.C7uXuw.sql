create view catalog_view as
select `test_table`.`category`.`category_id`         AS `category_id`,
       `test_table`.`category`.`category_name`       AS `category_name`,
       `test_table`.`subcategory`.`subcategory_id`   AS `subcategory_id`,
       `test_table`.`subcategory`.`subcategory_name` AS `subcategory_name`
from `test_table`.`category`
         join `test_table`.`subcategory`
         join `test_table`.`product_catalog_tbl`
where ((`test_table`.`category`.`category_id` = `test_table`.`product_catalog_tbl`.`category_id`) and
       (`test_table`.`subcategory`.`subcategory_id` = `test_table`.`product_catalog_tbl`.`subcategory_id`))
group by `test_table`.`subcategory`.`subcategory_name`, `test_table`.`category`.`category_name`,
         `test_table`.`category`.`category_id`, `test_table`.`subcategory`.`subcategory_id`;

